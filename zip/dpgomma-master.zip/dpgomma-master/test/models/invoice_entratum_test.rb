require 'test_helper'

class InvoiceEntratumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
