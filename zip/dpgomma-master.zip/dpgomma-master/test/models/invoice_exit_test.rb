require 'test_helper'

class InvoiceExitTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
