require 'test_helper'

class ExitTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
