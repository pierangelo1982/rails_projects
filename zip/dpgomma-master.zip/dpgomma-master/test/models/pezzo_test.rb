require 'test_helper'

class PezzoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
