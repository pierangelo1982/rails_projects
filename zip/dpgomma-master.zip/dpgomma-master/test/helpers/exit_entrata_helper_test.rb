require 'test_helper'

class ExitEntrataHelperTest < ActionView::TestCase
end
