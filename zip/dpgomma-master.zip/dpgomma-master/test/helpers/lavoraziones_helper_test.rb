require 'test_helper'

class LavorazionesHelperTest < ActionView::TestCase
end
