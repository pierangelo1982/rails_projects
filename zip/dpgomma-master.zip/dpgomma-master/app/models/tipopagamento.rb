class Tipopagamento < ActiveRecord::Base
end
