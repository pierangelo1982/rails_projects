class Lavorazione < ActiveRecord::Base
  belongs_to :pezzo
end
