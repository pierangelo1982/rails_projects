class Azienda < ActiveRecord::Base
	has_many :pezzos
end
