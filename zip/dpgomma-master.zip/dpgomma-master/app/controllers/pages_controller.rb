class PagesController < ApplicationController
 
  def fattura
  end

end
