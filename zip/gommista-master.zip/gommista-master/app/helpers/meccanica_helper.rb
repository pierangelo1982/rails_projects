module MeccanicaHelper
end
