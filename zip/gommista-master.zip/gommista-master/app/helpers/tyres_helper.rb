module TyresHelper
end
