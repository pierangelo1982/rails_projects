class IntroController < ApplicationController

 def index  	
  end
end
