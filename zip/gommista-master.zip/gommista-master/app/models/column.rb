class Column < ActiveRecord::Base
  belongs_to :floor
end
