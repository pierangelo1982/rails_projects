class Scriviwork < ActiveRecord::Base
  belongs_to :extrawork
end
