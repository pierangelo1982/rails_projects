class Catextrawork < ActiveRecord::Base
	belongs_to :extralavorowork
end
