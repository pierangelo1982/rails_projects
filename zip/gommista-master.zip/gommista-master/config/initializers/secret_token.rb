# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Gommista::Application.config.secret_key_base = 'ac2e6049d0f9a3c6cfed52904ba014112e446e6ddcb81a113d55db62f3471c587088c434b31b0d313c25fa4280d204ed1ce056b405302087fa7ddc850c9021fa'
