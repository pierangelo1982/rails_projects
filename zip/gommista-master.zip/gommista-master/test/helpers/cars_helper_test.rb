require 'test_helper'

class CarsHelperTest < ActionView::TestCase
end
