require 'test_helper'

class ExtraworksHelperTest < ActionView::TestCase
end
