require 'test_helper'

class ShelvesHelperTest < ActionView::TestCase
end
