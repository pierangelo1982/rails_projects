require 'test_helper'

class ExtralavoroworksHelperTest < ActionView::TestCase
end
