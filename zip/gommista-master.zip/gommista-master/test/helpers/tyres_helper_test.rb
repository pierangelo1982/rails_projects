require 'test_helper'

class TyresHelperTest < ActionView::TestCase
end
