require 'test_helper'

class OwnersHelperTest < ActionView::TestCase
end
