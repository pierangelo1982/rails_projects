require 'test_helper'

class MeccanicaHelperTest < ActionView::TestCase
end
