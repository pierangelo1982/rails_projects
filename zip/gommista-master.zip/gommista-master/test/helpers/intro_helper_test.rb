require 'test_helper'

class IntroHelperTest < ActionView::TestCase
end
