require 'test_helper'

class ScriviworksHelperTest < ActionView::TestCase
end
