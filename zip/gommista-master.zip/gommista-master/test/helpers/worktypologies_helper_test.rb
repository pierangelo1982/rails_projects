require 'test_helper'

class WorktypologiesHelperTest < ActionView::TestCase
end
