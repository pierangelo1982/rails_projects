require 'test_helper'

class WorktypesHelperTest < ActionView::TestCase
end
