require 'test_helper'

class ColumnsHelperTest < ActionView::TestCase
end
