require 'test_helper'

class FloorsHelperTest < ActionView::TestCase
end
