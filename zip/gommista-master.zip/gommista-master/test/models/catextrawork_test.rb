require 'test_helper'

class CatextraworkTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
