require 'test_helper'

class FloorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
