require 'test_helper'

class WorktypologyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
