require 'test_helper'

class WorktypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
