require 'test_helper'

class ScriviworkTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
