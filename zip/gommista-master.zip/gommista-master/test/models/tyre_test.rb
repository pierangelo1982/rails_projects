require 'test_helper'

class TyreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
