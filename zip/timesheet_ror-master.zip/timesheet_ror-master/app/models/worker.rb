class Worker < ActiveRecord::Base
  belongs_to :role
end
