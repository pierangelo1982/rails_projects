require 'test_helper'

class AddLatitudeLongitudeToTimesheetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
