require 'test_helper'

class PaymentTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
