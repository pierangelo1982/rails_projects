require 'test_helper'

class InvoiceArticleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
