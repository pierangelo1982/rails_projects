require 'test_helper'

class CustumerBankTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
