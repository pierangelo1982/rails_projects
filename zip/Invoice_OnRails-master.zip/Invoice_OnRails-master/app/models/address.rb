class Address < ActiveRecord::Base
  belongs_to :custumer
end
