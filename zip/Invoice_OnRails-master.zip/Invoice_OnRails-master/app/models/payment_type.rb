class PaymentType < ActiveRecord::Base
end
