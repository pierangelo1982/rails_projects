class CustumerBank < ActiveRecord::Base
  belongs_to :custumer
end
