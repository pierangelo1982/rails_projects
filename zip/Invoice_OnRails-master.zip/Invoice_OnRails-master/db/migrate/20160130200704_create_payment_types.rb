class CreatePaymentTypes < ActiveRecord::Migration
  def change
    create_table :payment_types do |t|
      t.string :titolo
      t.text :descrizione

      t.timestamps null: false
    end
  end
end
