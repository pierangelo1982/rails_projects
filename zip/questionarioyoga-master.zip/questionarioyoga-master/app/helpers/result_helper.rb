module ResultHelper
end
