require 'test_helper'

class QuestionarioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
