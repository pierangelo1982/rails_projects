# Preview all emails at http://localhost:3000/rails/mailers/questionario
class QuestionarioPreview < ActionMailer::Preview

end
