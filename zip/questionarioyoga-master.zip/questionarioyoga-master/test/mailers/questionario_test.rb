require 'test_helper'

class QuestionarioTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
