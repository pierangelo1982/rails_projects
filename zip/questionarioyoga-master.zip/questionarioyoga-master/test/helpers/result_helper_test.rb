require 'test_helper'

class ResultHelperTest < ActionView::TestCase
end
