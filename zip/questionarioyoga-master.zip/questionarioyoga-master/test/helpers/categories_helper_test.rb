require 'test_helper'

class CategoriesHelperTest < ActionView::TestCase
end
