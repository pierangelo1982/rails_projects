require 'test_helper'

class QuestionariodataHelperTest < ActionView::TestCase
end
