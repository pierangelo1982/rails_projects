require 'test_helper'

class QuestionariosHelperTest < ActionView::TestCase
end
