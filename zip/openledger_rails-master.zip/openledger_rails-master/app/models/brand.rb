class Brand < ApplicationRecord
	has_many :products
end
