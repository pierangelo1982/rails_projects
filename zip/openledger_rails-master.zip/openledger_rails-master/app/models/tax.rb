class Tax < ApplicationRecord
end
