class PaymentMethod < ApplicationRecord
end
