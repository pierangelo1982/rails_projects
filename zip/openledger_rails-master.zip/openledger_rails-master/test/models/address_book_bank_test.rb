require 'test_helper'

class AddressBookBankTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
