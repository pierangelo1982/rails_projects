require 'test_helper'

class PurchasePaymentDeadlineTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
