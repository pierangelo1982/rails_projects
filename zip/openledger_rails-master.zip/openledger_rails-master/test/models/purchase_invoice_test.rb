require 'test_helper'

class PurchaseInvoiceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
