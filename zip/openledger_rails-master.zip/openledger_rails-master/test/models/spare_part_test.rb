require 'test_helper'

class SparePartTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
