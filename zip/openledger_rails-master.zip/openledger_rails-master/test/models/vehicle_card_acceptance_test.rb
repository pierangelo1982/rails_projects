require 'test_helper'

class VehicleCardAcceptanceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
