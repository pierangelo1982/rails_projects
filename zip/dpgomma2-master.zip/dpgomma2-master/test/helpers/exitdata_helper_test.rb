require 'test_helper'

class ExitdataHelperTest < ActionView::TestCase
end
