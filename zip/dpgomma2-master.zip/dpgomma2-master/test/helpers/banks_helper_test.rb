require 'test_helper'

class BanksHelperTest < ActionView::TestCase
end
