require 'test_helper'

class TaxationsHelperTest < ActionView::TestCase
end
