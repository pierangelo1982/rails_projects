require 'test_helper'

class PezzosHelperTest < ActionView::TestCase
end
