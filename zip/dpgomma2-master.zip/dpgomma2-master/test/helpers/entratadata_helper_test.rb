require 'test_helper'

class EntratadataHelperTest < ActionView::TestCase
end
