require 'test_helper'

class InternodataHelperTest < ActionView::TestCase
end
