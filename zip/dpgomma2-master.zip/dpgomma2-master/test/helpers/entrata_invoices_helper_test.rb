require 'test_helper'

class EntrataInvoicesHelperTest < ActionView::TestCase
end
