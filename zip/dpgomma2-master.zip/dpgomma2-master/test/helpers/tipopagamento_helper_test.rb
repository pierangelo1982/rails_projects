require 'test_helper'

class TipopagamentoHelperTest < ActionView::TestCase
end
