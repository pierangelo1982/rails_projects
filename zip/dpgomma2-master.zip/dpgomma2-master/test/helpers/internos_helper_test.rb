require 'test_helper'

class InternosHelperTest < ActionView::TestCase
end
