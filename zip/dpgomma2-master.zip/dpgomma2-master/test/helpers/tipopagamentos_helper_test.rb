require 'test_helper'

class TipopagamentosHelperTest < ActionView::TestCase
end
