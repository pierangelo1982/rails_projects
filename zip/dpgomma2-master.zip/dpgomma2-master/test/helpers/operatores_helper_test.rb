require 'test_helper'

class OperatoresHelperTest < ActionView::TestCase
end
