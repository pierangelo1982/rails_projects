require 'test_helper'

class InvoiceextrasHelperTest < ActionView::TestCase
end
