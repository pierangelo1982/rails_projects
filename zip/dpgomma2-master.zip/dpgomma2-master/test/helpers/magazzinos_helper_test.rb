require 'test_helper'

class MagazzinosHelperTest < ActionView::TestCase
end
