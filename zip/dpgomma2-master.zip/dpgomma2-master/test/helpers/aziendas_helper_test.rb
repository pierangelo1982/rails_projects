require 'test_helper'

class AziendasHelperTest < ActionView::TestCase
end
