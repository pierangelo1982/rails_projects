require 'test_helper'

class ScadenzapagamentosHelperTest < ActionView::TestCase
end
