require 'test_helper'

class OperatorsHelperTest < ActionView::TestCase
end
