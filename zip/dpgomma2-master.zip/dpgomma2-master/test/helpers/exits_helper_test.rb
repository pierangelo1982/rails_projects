require 'test_helper'

class ExitsHelperTest < ActionView::TestCase
end
