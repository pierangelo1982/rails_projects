require 'test_helper'

class EntrataHelperTest < ActionView::TestCase
end
