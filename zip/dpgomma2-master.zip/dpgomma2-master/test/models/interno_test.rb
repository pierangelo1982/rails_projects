require 'test_helper'

class InternoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
