require 'test_helper'

class OperatoreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
