require 'test_helper'

class MagazzinoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
