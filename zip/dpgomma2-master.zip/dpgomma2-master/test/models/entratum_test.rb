require 'test_helper'

class EntratumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
