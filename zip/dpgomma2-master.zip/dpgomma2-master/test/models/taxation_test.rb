require 'test_helper'

class TaxationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
