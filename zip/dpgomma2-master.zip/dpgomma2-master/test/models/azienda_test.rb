require 'test_helper'

class AziendaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
