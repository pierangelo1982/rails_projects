require 'test_helper'

class ExitEntratumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
