require 'test_helper'

class TipopagamentoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
