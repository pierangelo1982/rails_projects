require 'test_helper'

class ExitdatumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
