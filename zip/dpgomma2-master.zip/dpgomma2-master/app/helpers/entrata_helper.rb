module EntrataHelper
end
