class Bank < ActiveRecord::Base
  belongs_to :azienda
end
