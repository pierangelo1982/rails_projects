class Scadenzapagamento < ActiveRecord::Base
  belongs_to :invoice
end
