class Internodatum < ActiveRecord::Base
  belongs_to :interno
  belongs_to :lavorazione
end
