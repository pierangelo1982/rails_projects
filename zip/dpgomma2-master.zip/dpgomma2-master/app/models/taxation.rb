class Taxation < ActiveRecord::Base

end
