class Operatore < ActiveRecord::Base
end
